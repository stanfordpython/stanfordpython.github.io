#!/usr/bin/env python3
"""
Triangulates the unicorn's location, based on a series of data points.
"""
import numpy as np
import pickle
import scipy.optimize

INPUT_FILENAME = 'unicorndata.pickle'

def load_data(filename):
    """
    Loads the unicorn data from a pickle file.

    Arguments:
    filename -- the file that contains the unicorn data

    Returns: a list of dictionaries, where each dictionary is of the form
    {
        "latitude": ...,
        "longitude": ...,
        "distance": ...
    }
    """
    pass

def clean_data(unicorn_data):
    """
    Cleans the unicorn data into two numpy arrays.

    Arguments:
    unicorn_data -- a list of dictionaries, where each dictionary is of the form
    {
        "latitude": ...,
        "longitude": ...,
        "distance": ...
    }

    Returns:
    X -- a numpy array of length 800 x 2 where each row has the form [lat, lng]
    y -- a 800-length numpy array, where y[i] is the noisy distance from the
         unicorn, associated with X[i]
    """
    pass

def process_prob_maximize(X, y):
    """
    Processes the unicorn data by maximizing a probability function that
    outputs the probability that (x,y) is the unicorn's location.

    Arguments:
    X -- an 800 x 2 numpy array, where each row is of the form [lat, lng],
         representing a single data point
    y -- a 800-length numpy array, where y[i] is the noisy distance from the
         unicorn, associated with X[i]

    Returns:
    lat -- the latitude coordinate of the unicorn
    lng -- the longitude coordinate of the unicorn
    """

    pass

def process_paraboloid_fit(X, y):
    """
    Processes the unicorn data by fitting a paraboloid to it and finds the
    minimum point of that paraboloid.

    Arguments:
    X -- an 800 x 2 numpy array, where each row is of the form [lat, lng],
         representing a single data point
    y -- a 800-length numpy array, where y[i] is the noisy distance from the
         unicorn, associated with X[i]

    Returns:
    lat -- the latitude coordinate of the unicorn
    lng -- the longitude coordinate of the unicorn
    """
    def prob(pt):
        """
        Computes the probability that pt is the location of the unicorn.
        """
        pass

    pass

def main():
    # Load data
    input("Press Enter to load the unicorn data...")
    unicorn_data = load_data(INPUT_FILENAME)

    # Inform user about data
    if unicorn_data is None:
        print("Warning: no data recieved. Is load_data implemented?")
    else:
        print("Zeroeth data point: {d[0]}".format(d=unicorn_data))
    print()

    # Clean data
    input("Press Enter to continue and clean the data...")
    try:
        X, y = clean_data(unicorn_data)
    except TypeError:
        X, y = None, None

    # Inform user about data
    if X is None and y is None:
        print("Warning: no data cleaned. Is clean_data implemented?")
    else:
        print("Row 0: {X[0]}, with noisy distance: {y[0]}".format(X=X, y=y))
    print()

    # Process data
    input("Press Enter to continue and process the data...")
    """
    Depending on your preferred way of triangulating the
    unicorn data, you may want to change this line.
    """
    process_data = process_paraboloid_fit # or `process_prob_maximize`
    try:
        lat, lng = process_data(X, y)
    except TypeError:
        lat, lng = None, None

    print("The unicorn is at {}, {}.".format(lat, lng))

if __name__ == '__main__':
    main()
