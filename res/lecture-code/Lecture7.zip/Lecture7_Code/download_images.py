#!/usr/bin/env python3

from threading import Thread
from io import BytesIO
from PIL import Image
import requests

def download_image(url):
	"""
	Downloads and opens the image located at "url"
	"""
    img_bytes = BytesIO(requests.get(url).content)
    image = Image.open(img_bytes)
    image.show()

if __name__ == "__main__":
	# List of urls from which to download images
	urls = ["https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/cb/4c/2a/cb4c2ae9-e011-4bca-6d1d-3c13d31a1e36/source/256x256bb.jpg",
	"https://teeshirtpalace-production.s3.amazonaws.com/spree/images/MERCN246-RED-TH-DESIGN/large/MERCN246-RED-TH-DESIGN.jpg?1550987276",
	"https://images-na.ssl-images-amazon.com/images/I/51f7rofepmL.jpg",
	"https://images-na.ssl-images-amazon.com/images/I/513KLIb5CwL.jpg",
	"https://i.pinimg.com/originals/23/95/26/2395267b14fe52559ed622eb4081f008.jpg"]

	for url in urls:
	    t = Thread(target=download_image, args=(url,))
	    t.start()

