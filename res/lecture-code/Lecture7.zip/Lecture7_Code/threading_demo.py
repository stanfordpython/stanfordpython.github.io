#!/usr/bin/env python3

import time
import threading

# sleep_lock = threading.Lock()

def sleep_thread(i):
    """
    Makes the given thread print a goodnight message, go
    to sleep for 5 seconds, then notify the user
    once it wakes up. Returns that it had a nice nap.
    """
    print("Thread {} is about to take a nap!".format(i))
    # sleep_lock.acquire()
    time.sleep(5)
    # sleep_lock.release()
    print("Thread {} has woken up from naptime!".format(i))

if __name__ == "__main__":
    """
    Spawn 10 threads, have them each call sleep_thread with
    argument i.
    """
    # thread_list = []

    for i in range(10):
        t = threading.Thread(target=sleep_thread, args=(i,))
        t.start()
        # thread_list.append(t)

    # for t in thread_list:
    #     t.join()
    # print("All threads have finished!")
