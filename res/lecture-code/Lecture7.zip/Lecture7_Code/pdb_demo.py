#!/usr/bin/env python3

def edit_list():
	"""
	Modify a list while iterating through it... what's
	the worst that could happen?
	"""
	item_list = [x for x in range(10)]

	for item in item_list:
		print(item)
		item_list.remove(item)

	print(item_list)

if __name__ == "__main__":
	edit_list()