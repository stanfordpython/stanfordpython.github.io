#!/usr/bin/env python3

import functools

def memoize(func):
	"""
	Decorate a function so that its output is memoized
	for recursive calls.
	"""
	mapping = {}
	# @functools.wraps(func)
	def func_with_memoization(*args):
		if output := mapping.get(args):
			return output
		else:
			mapping[args] = func(*args)
			return mapping[args]
	return func_with_memoization

@memoize
def fibonacci(n):
	"""
	Recursively find the nth fibonacci number!
	"""
	if n == 1 or n == 0:
		return n
	else:
		return fibonacci(n-1) + fibonacci(n-2)

if __name__ == "__main__":
	print(fibonacci.__name__)
	print(fibonacci.__doc__)
	print(fibonacci(100))