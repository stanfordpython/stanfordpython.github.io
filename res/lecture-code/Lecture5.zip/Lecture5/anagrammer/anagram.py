from flask import Flask, render_template, request

app = Flask(__name__)
DICTIONARY_FILE = '/usr/share/dict/words'

def canonical_representation(word):
    """
    Return a canonical representation of word that is the same for two anagrams.
    """
    return ''.join(sorted(word.strip().upper()))

def build_anagrams_dict():
    """
    Builds a dictionary of anagrams that associates
        {
            CANONICAL_REP: [list, of, anagrams, for, CANONICAL_REP]
        }
    """
    out = {}

    with open(DICTIONARY_FILE, 'r') as f:
        for line in f:
            word = line.strip().upper()
            canonical_rep = canonical_representation(word)

            out[canonical_rep] = out.get(canonical_rep, []) + [word]

    return out

@app.route('/')
def main():
    return render_template('index.html')

@app.route('/anagram', methods=('GET',))
def compute_anagrams():
    """
    Builds the anagrams dictionary and queries it with the provided code.
    """
    word = request.args.get('word')

    # Need to serve {'word': word.upper(), 'anagrams': anagrams}
    pass