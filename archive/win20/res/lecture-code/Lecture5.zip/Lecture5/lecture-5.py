#!/usr/bin/env python3
"""
Code from CS 41: Lecture 5 (Python and the Web)

@psarin 02-03-2020  Created file
"""

def review():
    """
    Review of Functional Programming
    """
    def echo(arg):
        return arg

    print(type(echo))
    print(id(echo))
    print(echo)

    foo = echo
    print(type(foo))
    print(id(foo))
    print(foo)

    print(isinstance(echo, object))

    def cache(fn):
        fn._cache = {}
        def modified_fn(*args):
            if args not in fn._cache:
                fn._cache[args] = fn(*args)

            return fn._cache[args]

        return modified_fn

    def fibbi(n):
        return fibbi(n-1) + fibbi(n-2) if n >= 2 else 1

    # Don't run these lines!
    # fibbi(100)  # => way too slow
    # fibbi(1000) # => RuntimeError

    @cache
    def fibbi(n):
        return fibbi(n-1) + fibbi(n-2) if n >= 2 else 1

    print(fibbi(100))  # => 573147844013817084101
    # print(fibbi(1000)) # => 703303677114228158...


def classes():
    """
    Code from section on Object-Oriented Python.
    """
    class MyClass:
        """A simple example class"""
        num = 41

        def greet(self):
            return "Hello world!"

    print(MyClass.num)   # => 41
    print(MyClass.greet) # => <function MyClass.greet>

    class Canadian:
        def __init__(self, first, middle, last, ssn=0):
            self.first_name = first
            self.middle_name = middle
            self.last_name = last
            self.ssn = ssn

    michael = Canadian('Michael', 'John', 'Cooper')

    print(michael.first_name)  # => 'Michael'
    print(michael.middle_name) # => 'John'
    print(michael.last_name)   # => 'Cooper'
    print(michael.ssn)         # => 0

    # michael.ssn = 4... (nice try, did you think you'd get Michael's Social Security Number? Only I (Parth) know that.)
    michael.middle_name = 'Jamiroquai'

    x = MyClass()
    print(type(x)) # => MyClass

    print(x.greet()) # => 'Hello world!'
    # Weird... doesn't `greet` need an argument?

    print(type(x.greet))       # => method
    print(type(MyClass.greet))# => function

    print(x.num is MyClass.num)    # => True
    print(x.greet is MyClass.greet) # => False

    class Unicorn:
        """
        A class to handle unicorn-related awesomeness.
        """
        def __init__(self, name, magic_capability=10):
            self.name = name
            self.magic_capability = magic_capability

        def cast_spell(self, chant, magic_required=1):
            if self.magic_capability >= magic_required:
                print(f"{chant}! The spell was cast.")
                self.magic_capability -= magic_required
            else:
                print(f"{self.name} isn't magical enough.")

    u = Unicorn('Unicornelius', magic_capability=3)

    print(Unicorn.cast_spell) # => <function Unicorn.cast_spell>
    print(u.cast_spell)       # => <bound method Unicorn.cast_spell of ...>

    u.cast_spell('Alohomora', magic_required=2)
    # (Implicitly calls Unicorn.cast_spell(u, 'Alohamora', magic_required=2))
    # Alohamora! The spell was cast.

    u.cast_spell('Wingardium Leviosa', magic_required=2)
    # Unicornelius isn't magical enough.                               


def web_requests():
    """
    Code from section of Web Requests.
    """
    import requests

    # Content-Type
    response = requests.get('https://www.google.com')
    print(response.headers.get('content-type')) # => 'text/html; charset=ISO-8859-1'

    """
    The website unicornpictures.com does not actually serve
    unicorn pictures, so this will not work:

    # Content
    response = requests.get('https://www.unicornpictures.com/')
    if response.ok:
        raw_data = repsonse.content
        json_data = response.json() # if the response is in JSON format

    # GET with parameters
    payload = {'filter': 'top', 'year': 2019}
    response = requests.get('https://www.unicornpictures.com/', 
                            params=payload)
    response.url # => https://www.unicornpictures.com/?filter=top&year=2019

    # POST with parameters
    payload = {'username': 'psarin', 'password': 'I <3 unic0rns'}
    response = requests.post('https://www.unicornpictures.com/login', 
                             data=payload)
    """


def images():
    """
    Code from the images portion of the lecture.
    """
    from PIL import Image

    # Open an image by filename
    # SUBSTITUTE THIS WITH A FILENAME THAT WORKS FOR YOU.
    filename = 'unicorn.png'
    im = Image.open(filename)

    """
    Other ways to open an image:

    # Open a file-like object
    with open(filename, 'rb') as f:
        im = Image.open(f)

    # Problem: What if we have an image as bytes?
    r = requests.get('https://unicornpictures.com/unicorn.png')
    r.content # => b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x03\x08...'

    # Solution: *Convert* it to a file-like object
    from io import BytesIO
    f = BytesIO(r.content) # simulates a file
    im = Image.open(f)
    """

    # Display the image in your default image software
    im.show()

    # Save the image as out_file
    # im.save(out_file)

    # Get metadata about the image
    print(im.format) # => 'PNG'
    print(im.size)   # => (776, 838)
    print(im.mode)   # => 'RGBA'

    ### MODIFY THE IMAGE
    # Crop to a box with (upper_left, lower_right)
    box = (100, 100, 400, 400)
    region = im.crop(box)
    region.show()

    # Geometric transforms
    out = im.resize((128, 128))
    out.show()

    out = im.rotate(45) # degrees counter-clockwise
    out.show()

    # Filter transformations
    from PIL import ImageFilter
    # Built-in filters:
    # - ImageFilter.BLUR
    # - ImageFilter.CONTOUR
    # - ImageFilter.DETAIL
    # - ImageFilter.EDGE_ENHANCE
    # - ImageFilter.EMBOSS
    # - ImageFilter.FIND_EDGES
    # - ImageFilter.SHARPEN
    # - ImageFilter.SMOOTH
    # - ...and more!
    out = im.filter(ImageFilter.BLUR)
    out.show()

    # Point operations
    out = im.point(lambda i: min(i, 150))
    out.show()

    # And, more generally...
    import numpy as np
    a = np.asarray(im)
    a.shape # => (838, 776, 4) == (width, height, num_channels)

    def transform(a):
        # Process `a` ...
        # return np.array(...)
        pass

    # Uncomment the next line if you implement `transform`
    # out = Image.fromarray(transform(a))


def main():
    """
    Runs all of the lecture's code.
    """
    review()
    classes()
    web_requests()
    images()


if __name__ == '__main__':
    main()