#!/usr/bin/env python3
"""
Requests information about https://reddit.com/r/cats
"""
import requests


def main():
    """
    Use requests to get information about /r/cats
    """
    headers = {'User-Agent': "CS 41's Fantastic User Agent"}
    r = requests.get("https://reddit.com/r/cats/.json", headers=headers)

    print(r)
    if r.ok:
        json_data = r.json()
        print(json_data.keys())
        print(json_data['data'].keys())
        
        print(len(json_data['data']['children']))

        print(json_data['data']['children'][3].keys())

        post_data = json_data['data']['children'][3]['data']
        print(post_data['title'])
        print(post_data.get('preview'))


if __name__ == '__main__':
    main()