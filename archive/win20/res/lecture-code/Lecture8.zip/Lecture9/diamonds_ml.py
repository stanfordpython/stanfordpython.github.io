#!/usr/bin/env python3

import numpy as np
import matplotlib.pyplot as plt
import sklearn.linear_model
from sklearn.neural_network import MLPRegressor, MLPClassifier

def load_dataset_regression(filename):
    """
    Loads the dataset from the file. Shuffles it, then
    adds it to NumPy matrices.

    Input:
    filename - the name of a .csv file to load.

    Output:
    X, Y - NumPy arrays extracted from the .csv file. X is
           the data, Y is the labels.
    """
    # The skiprows=1 argument skips the first row, where the data labels are
    with open(filename, "r") as f:
        dataset = np.loadtxt(f, delimiter=",", skiprows=1)

    # Shuffle the dataset before splitting into train, validation, and test sets - this is
    # important to ensure an even distribution of datapoints in the train, validation,
    # and test sets.
    np.random.shuffle(dataset)

    # X is all columns except the "price" column
    X = dataset[:,:-2]
    # Y is the "price" column
    Y = dataset[:,-2]
    return X, Y

def load_dataset_classification(filename):
    """
    Loads the dataset from the file. Shuffles it, then
    adds it to NumPy matrices.

    Input:
    filename - the name of a .csv file to load.

    Output:
    X, Y - NumPy arrays extracted from the .csv file. X is
           the data, Y is the labels.
    """
    # The skiprows=1 argument skips the first row, where the data labels are
    with open(filename, "r") as f:
        dataset = np.loadtxt(f, delimiter=",", skiprows=1)
        
    # Shuffle the dataset before splitting into train, validation, and test sets - this is
    # important to ensure an even distribution of datapoints in the train, validation,
    # and test sets.
    np.random.shuffle(dataset)

    # X is all columns except the "price", "class" columns
    X = dataset[:,:-2]
    # Y is the "class" column
    Y = dataset[:,-1]
    return X, Y

def view_data(X, Y):
    """
    Produces plots of each variable in X with respect to
    the prediction variable of interest, Y.

    Input:
    X, Y - NumPy arrays representing features and labels,
           respectively.
    
    Output:
    None - but visualizes graphs with plt.show()
    """
    feature_labels = ["Carat", "Depth", "Table", "X Measurement", "Y Measurement", "Z Measurement"]
    for col in range(X.shape[1]):
        # Plot each column with respect to Y to look at variable relationship.
        plt.clf()
        plt.scatter(X[:, col], Y)
        plt.xlabel(feature_labels[col])
        plt.ylabel("Price")
        plt.show()

def split_data(X, Y):
    """
    Given data and labels, divides the data into training and
    validation sets. Here, we use an 80%-20% split where the 80%
    is the training data, and the 20% is the validation data.

    In a real ML project (i.e. not a demo for CS41), we would have
    a test set, and would probably do an 80%-10%-10% split.

    Input:
    X, Y - NumPy arrays representing features and labels,
           respectively.

    Output:
    X_train, Y_train, X_valid, Y_valid - NumPy arrays representing the
                                         training and validation sets.
    """
    X_train = X[:round(X.shape[0]*0.8),:]
    X_valid = X[round(X.shape[0]*0.8):,:]

    Y_train = Y[:round(Y.shape[0]*0.8)]
    Y_valid = Y[round(Y.shape[0]*0.8):]

    return X_train, Y_train, X_valid, Y_valid

def least_squares_linear_regression_example(X_train, Y_train, X_valid, Y_valid):
    """
    Run least squares regression on the training set. Print out the loss. Then
    run a series of examples showing predictions and their true values.

    Input:
    X_train, Y_train, X_valid, Y_valid - NumPy arrays representing the
                                         training and validation sets.

    Output:
    None
    """
    thetas = np.linalg.lstsq(X_train, Y_train, rcond=None)
    print("Loss: {}".format(np.sqrt(np.sum(np.square( np.dot(X_train, thetas[0]) - Y_train )))))

    for i, example in enumerate(X_valid):

        print("Predicted price: {}".format(round(np.dot(np.array(example), thetas[0]), 2)))
        print("Actual price: {}".format(Y_valid[i]))
        user_in = input("Would you like to see another prediction? ")
        if user_in.lower() not in ["y", "yes"]:
            break

def squared_feature_selection(X_train, Y_train):
    """
    Augments our features by adding an additional column to the left:
    carat**2, to account for an observed nonlinearity in the dataset.

    In this way we can... wait for it... approximate nonlinear models
    with linear estimator functions! Isn't that so cool?!

    Input:
    X_train, Y_train - NumPy arrays representing training set and labels, respectively.

    Output:
    None - prints out standard training loss and training loss with
           enhanced feature matrix.
    """
    thetas = np.linalg.lstsq(X_train, Y_train, rcond=None)
    print("Standard Training Loss: {}".format(np.sqrt(np.sum(np.square( np.dot(X_train, thetas[0]) - Y_train )))))

    # Feature selection - let's add in a column of the "Carat" term squared.
    carat_feature_train = (X_train[:,0]**2).reshape(X_train.shape[0], 1)
    X_train = np.concatenate((carat_feature_train, X_train), axis=1)

    thetas = np.linalg.lstsq(X_train, Y_train, rcond=None)
    print("Squared Training Loss: {}".format(np.sqrt(np.sum(np.square( np.dot(X_train, thetas[0]) - Y_train )))))

def NN_regressor(X_train, Y_train, X_valid, Y_valid):
    """
    Trains a neural network to perform regression on the dataset. Makes predictions
    on the validation set, and prints out the validation loss from a least squares
    regression versus that of the neural network regression.

    Input:
    X_train, Y_train, X_valid, Y_valid - NumPy arrays representing the
                                         training and validation sets.
    
    Output:
    None - prints out validation loss of NN and least squares regression.
    """
    clf = MLPRegressor(hidden_layer_sizes=(32, 64, 128, 64, 32), learning_rate_init=0.0008, max_iter=400, verbose=True).fit(X_train, Y_train)

    predictions = clf.predict(X_valid)

    thetas = np.linalg.lstsq(X_train, Y_train, rcond=None)
    print("Least Squares Validation Loss: {}".format(np.sqrt(np.sum(np.square( np.dot(X_valid, thetas[0]) - Y_valid )))))

    print("NN Valiation Loss: {}".format(np.sqrt(np.sum(np.square( predictions - Y_valid )))))

def least_squares_logistic_regression_classifier(X_train, Y_train, X_valid, Y_valid):
    """
    Trains a binary classification model using stochastic gradient descent. Prints out
    the validation accuracy of the model.

    Input:
    X_train, Y_train, X_valid, Y_valid - NumPy arrays representing the
                                         training and validation sets.
    
    Output:
    None - prints out logitsic regression classification accuracy.
    """

    # This .fit(X, Y) function uses gradient descent to optimize its parameter values.
    clf = sklearn.linear_model.LogisticRegression(penalty="l2").fit(X_train, Y_train)
    predictions = clf.predict(X_valid)

    num_correct = len([i for i in range(len(Y_valid)) if Y_valid[i] == predictions[i]])

    print("Logistic Regression Accuracy: {} / {}".format(num_correct, len(Y_valid)))

def NN_classifier(X_train, Y_train, X_valid, Y_valid):
    """
    Trains a neural network to perform binary classification on the dataset. Makes predictions
    on the validation set, and prints out the neural network classification accuracy.

    Input:
    X_train, Y_train, X_valid, Y_valid - NumPy arrays representing the
                                         training and validation sets.
    
    Output:
    None - prints out NN classification accuracy.
    """
    clf = MLPClassifier(hidden_layer_sizes=(32, 64, 128, 64, 32), learning_rate_init=0.0008, max_iter=400, verbose=True).fit(X_train, Y_train)

    predictions = clf.predict(X_valid)

    num_correct = len([i for i in range(len(Y_valid)) if Y_valid[i] == predictions[i]])

    print("NN Classification Accuracy: {} / {}".format(num_correct, len(Y_valid)))

if __name__ == "__main__":

    # Toggle the functions here to explore different facets of machine
    # learning!

    # Regression
    X, Y = load_dataset_regression("diamonds.csv")
    view_data(X, Y)
    # X_train, Y_train, X_valid, Y_valid = split_data(X, Y)
    # least_squares_linear_regression_example(X_train, Y_train, X_valid, Y_valid)
    # squared_feature_selection(X_train, Y_train)
    # NN_regressor(X_train, Y_train, X_valid, Y_valid)

    # Classification
    # X, Y = load_dataset_classification("diamonds.csv")
    # view_data(X, Y)
    # X_train, Y_train, X_valid, Y_valid = split_data(X, Y)
    # least_squares_logistic_regression_classifier(X_train, Y_train, X_valid, Y_valid)
    # NN_classifier(X_train, Y_train, X_valid, Y_valid)


