# Imports go at the top
from microbit import *
import radio
import random
radio.on()
radio.config(length=200)
# Code in a 'while True:' loop repeats forever
last_contact = 0
while True:
    sleep(5)
    radio.send("MICRO1:chaseeunbeatable.pythonanywhere.com/1")
    confirmation = radio.receive()
    if not confirmation is None and "MICRO1" in str(confirmation):     
        payload = radio.receive()
        if not payload is None:
            payload = str(payload)
            display.clear()
            if "1" in payload:
                display.set_pixel(2,2,9)
                last_contact = 0
            else:
                last_contact += 1
                if last_contact > 1000:
                    display.clear()
                    last_contact = 0
            
        
