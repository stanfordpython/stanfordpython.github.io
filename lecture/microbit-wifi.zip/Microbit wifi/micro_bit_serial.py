# Imports go at the top
from microbit import *
import radio
# Code in a 'while True:' loop repeats forever

uart.init(115200)
radio.on()
radio.config(length=200)
while True:
    sleep(5)
    message = radio.receive()# send in the following format
    # DEVICE_ID:payload
    # no spaces and the ID can be arbitrary
    if not message is None:
        message = str(message)
        payload = message.split(":")
        return_msg = payload[0] + " confirmed"
        radio.send(return_msg)
        uart.write(payload[1] + "\n")
        response = uart.readline()
        if response is None:
            radio.send("ERROR")
        else:
            radio.send(str(response))

            
