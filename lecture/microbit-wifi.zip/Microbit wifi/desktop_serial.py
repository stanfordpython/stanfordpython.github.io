import serial
import requests
# Run this in terminsl to find the name
# ls -l /dev/cu.usb*
# example you will need to change this
PORT_NAME = '/dev/cu.usbmodem1302' 
def main():
    ser = serial.Serial(PORT_NAME)
    ser.baudrate = 115200
    while True:       
        line = str(ser.readline())
        line = line[2:len(line) - 3] # when converting to byte array to string some extra data is appended on
        line = "https://" + line
        print(line)
        try:
            r = requests.get(line)
            ret = r.text.replace('\n', '***LINE_BREAK_WAS_HERE***') # on the microbit end swap back to line break
            ret = str(ret) + "\n"
            print(ret)
            ret = ret.encode('utf-8')
            ser.write(ret)
            print("success")
        except:
            print("ERROR")
            ser.write(b'ERROR') # catch this in your code



if __name__ == "__main__":
    main()