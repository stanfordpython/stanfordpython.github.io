from flask import Flask


app = Flask(__name__)
SECRET_NUMBER = 41

@app.route('/<guess>', methods=['GET'])
def check(guess):
    # 1. convert guess into an integer
    try:
        guess = int(guess)
    except ValueError:
        return {'error': 'Thats not an integer!'}

    # 2. compare it to the secret number
    output = {'correct': guess == SECRET_NUMBER}
    if guess < SECRET_NUMBER:
        output['error'] = 'too low'
    elif guess > SECRET_NUMBER:
        output['error'] = 'too high'
    else:
        output['message'] = 'congrats! you got it :)'

    return output


@app.route('/', methods=['GET'])
def index():
    return 'Hello world!'



if __name__ == '__main__':
	app.run()
