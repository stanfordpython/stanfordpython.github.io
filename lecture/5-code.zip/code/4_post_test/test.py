import requests

url = "http://127.0.0.1:5000/"
myobj = {'to_add': ''}

x = requests.post(url, json = myobj)
