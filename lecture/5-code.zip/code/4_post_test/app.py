from flask import Flask, render_template, request

app = Flask(__name__)

items = []

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        item = request.get_json()
        items.append(item["to_add"])
    return render_template('login.html', items=items)


if __name__ == '__main__':
    app.run()
