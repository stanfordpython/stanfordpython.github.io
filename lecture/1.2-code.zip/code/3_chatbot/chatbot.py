"""
File: dictionary_chatbot.py
---------------------------

Checks if words are in the dictionary.
"""

WORDS_FILE = 'words.txt'
DEFINITIONS_FILE = 'definitions.txt'


def is_word(guess):
    ...


def get_definition(guess):
    ...


def main():
    """
    A chatbot which repeatedly prompts the user for a word and checks if it's in
    the dictionary.
    """
    # 1. Introduce yourself!
    # 2. Repeatedly ask the user for input and handle the input


if __name__ == '__main__':
    main()
