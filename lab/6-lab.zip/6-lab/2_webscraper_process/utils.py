"""
File: utils.py
--------------

This file contains utility functions for the webscraper.
"""
from pickle import load, dump
import re
from os import system
from os.path import isfile
from pyvis.network import Network

GRAPH_FILE = 'graph.pkl'
URL_REGEX = re.compile(
    r'(?:http|ftp|https):\/\/(?:[\w_-]+(?:(?:\.[\w_-]+)+))(?:[\w.,@?^=%&:\/~+#-]*[\w@?^=%&\/~+#-])'
)

def save_graph(graph):
    with open(GRAPH_FILE, 'wb') as f:
        dump(graph, f)


def load_graph():
    if not isfile(GRAPH_FILE):
        return None
    
    print(f'{GRAPH_FILE} found on your system...')
    print('You can load the graph from a file to avoid having to scrape the web again.')
    ans = input('Do you want to load the graph from file? (y/n) ')
    if ans.lower() == 'y':
        return load(open(GRAPH_FILE, 'rb'))


def create_network(graph):
    # Create the graph
    net = Network(notebook=True)

    # Add all the nodes
    nodes = set()
    for url, links in graph.items():
        nodes.add(url)
        nodes |= set(links)
    net.add_nodes(nodes)

    # Add all the edges
    for url, links in graph.items():
        for link in links:
            net.add_edge(url, link)

    # Save the graph
    net.show_buttons(filter_=['physics'])
    net.toggle_physics(False)
    net.show('graph.html')
    system('open graph.html')