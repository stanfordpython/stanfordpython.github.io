"""
File: webscraper.py
-------------------

This program scrapes the web, starting at a specified website and following
links to other websites. It will continue to follow links until it has visited
a specified number of pages (specified in the constant MAX_PAGES) or until it
has visited every page in the network.

Requirements:
- requests
- pyvis

Usage: python webscraper.py [url]

Try scraping the url 'https://old.reddit.com/r/unicorns/'!
"""
import requests
from sys import argv
import multiprocessing as mp
from functools import partial
from utils import save_graph, load_graph, create_network, URL_REGEX

# Constants
MAX_PAGES = 100
NUM_WORKERS = 16


def get_links(url):
    """
    Returns a list of all the links on the given url.
    """
    r = requests.get(url)
    return URL_REGEX.findall(r.text)


def worker(task_q, resp_q, w_id):
    print(f'Worker {w_id} started!')
    while True:
        url = task_q.get()
        links = get_links(url)
        resp_q.put((url, links))
        print(f'Visited {url} and retrieved {len(links)} links.')


def explore(start_url):
    num_visited = 0
    visited = set()
    graph = {} # format as {url: [list of urls it connects to]}

    manager = mp.Manager()
    task_q = manager.Queue()
    resp_q = manager.Queue()
    
    try:
        pool = [
            mp.Process(target=worker, args=(task_q, resp_q, w_id))
            for w_id in range(NUM_WORKERS)
        ]
        for p in pool:
            p.start()
        
        # Keep track of how many pages we've visited
        task_q.put(start_url)
        while num_visited < MAX_PAGES:
            url, links = resp_q.get()
            
            # Update the graph and visited set
            num_visited += 1
            visited.add(url)
            graph[url] = links

            # Add all the links to the task queue
            for link in links:
                if link not in visited:
                    task_q.put(link)
        
        # Stop all the workers
        for p in pool:
            p.terminate()
    except mp.TimeoutError:
        pass

    return graph


def main():
    g = load_graph()
    if g is not None:
        create_network(g)
        return

    assert len(argv) == 2, 'Usage: python webscraper.py [url]'
    graph = explore(argv[1])
    print('Exploring complete!')
    print(
        f'Graph contains {len(graph)} nodes and '
        f'{sum(len(links) for links in graph.values())} edges.'
    )
    save_graph(graph)
    create_network(graph)


if __name__ == '__main__':
    main()
