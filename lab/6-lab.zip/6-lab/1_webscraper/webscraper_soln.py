"""
File: webscraper.py
-------------------

This program scrapes the web, starting at a specified website and following
links to other websites. It will continue to follow links until it has visited
a specified number of pages (specified in the constant MAX_PAGES) or until it
has visited every page in the network.

Requirements:
- requests
- pyvis


Usage: python webscraper.py [url]

Try scraping the url 'https://old.reddit.com/r/unicorns/'!
"""
import requests
from sys import argv
from threading import Thread
from utils import save_graph, load_graph, create_network, URL_REGEX

# Constants
MAX_PAGES = 100
NUM_WORKERS = 16

# Global variables
num_visited = 0
to_visit = []
visited = set()
graph = {} # format as {url: [list of urls it connects to]}


def get_links(url):
    """
    Returns a list of all the links on the given url.
    """
    r = requests.get(url)
    return URL_REGEX.findall(r.text)


def worker():
    global num_visited, to_visit, visited, graph
    while True:
        # Get the next URL to visit
        if to_visit and num_visited < MAX_PAGES:
            url = to_visit.pop(0)
        else:
            return

        # Visit this URL
        visited.add(url)
        num_visited += 1
        links = get_links(url)

        # Add this URL to the graph, along with all of its links
        graph[url] = links
        next_pages = [l for l in links if l not in visited]
        to_visit.extend(next_pages)
        print(f'Visited {url} ({num_visited} of {MAX_PAGES} pages)')


def explore(start_url):
    to_visit.append(start_url)
    threads = [Thread(target=worker) for _ in range(NUM_WORKERS)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()


def main():
    global graph
    g = load_graph()

    if g is not None:
        create_network(g)
        return

    assert len(argv) == 2, 'Usage: python webscraper.py [url]'
    explore(argv[1])
    print('Exploring complete!')
    print(
        f'Graph contains {len(graph)} nodes and '
        f'{sum(len(links) for links in graph.values())} edges.'
    )
    save_graph(graph)
    create_network(graph)


if __name__ == '__main__':
    main()