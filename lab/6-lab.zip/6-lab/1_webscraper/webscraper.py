"""
File: webscraper.py
-------------------

This program scrapes the web, starting at a specified website and following
links to other websites. It will continue to follow links until it has visited
a specified number of pages (specified in the constant MAX_PAGES) or until it
has visited every page in the network.

Requirements:
- requests
- pyvis

Usage: python webscraper.py [url]

Try scraping the url 'https://old.reddit.com/r/unicorns/'!
"""
import requests
from sys import argv
from threading import Thread
from utils import save_graph, load_graph, create_network, URL_REGEX

# Constants
MAX_PAGES = 100
NUM_WORKERS = 16

# Global variables
num_visited = 0
to_visit = []
visited = set()
graph = {} # format as {url: [list of urls it connects to]}


def get_links(url):
    """
    Returns a list of all the links on the given url.
    """
    r = requests.get(url)
    return URL_REGEX.findall(r.text)


def worker():
    """
    TODO: Each worker should...
        1. Check if num_visited < MAX_PAGES. If not, return.
        2. Get the next URL to visit from the to_visit list.
        3. Visit this URL, increment num_visited, and add it to visited.
        4. Update the graph with this URL and its links.
    
    Remember to avoid re-visiting URLs!
    """
    global num_visited, to_visit, visited, graph
    while True:
        ...


def explore(start_url):
    """
    TODO: Create NUM_WORKERS threads, each of which will run the worker 
    function. Remember to join all of the threads at the end!
    """
    to_visit.append(start_url)
    ...


def main():
    global graph
    g = load_graph()

    if g is not None:
        create_network(g)
        return

    assert len(argv) == 2, 'Usage: python webscraper.py [url]'
    explore(argv[1])
    print('Exploring complete!')
    print(
        f'Graph contains {len(graph)} nodes and '
        f'{sum(len(links) for links in graph.values())} edges.'
    )
    save_graph(graph)
    create_network(graph)


if __name__ == '__main__':
    main()
