#define PY_SSIZE_T_CLEAN
#include <Python.h>

static PyObject*
example(PyObject *self, PyObject *args) {
  return PyErr_Format(
    PyExc_NotImplementedError,
    "The function hasn't been implemented"
  );
}

static PyMethodDef ExampleModuleMethods[] = {
    {"example", example, METH_VARARGS, "Example function definition"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef module = {
    PyModuleDef_HEAD_INIT,
    "...", // replace with the module name
    "...", // replace with a module description
    -1,
    ExampleModuleMethods
};

PyMODINIT_FUNC PyInit_example(void)
{
  return PyModule_Create(&module);
}
