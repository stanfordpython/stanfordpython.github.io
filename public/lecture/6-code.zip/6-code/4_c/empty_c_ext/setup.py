from distutils.core import setup, Extension

def main():
    setup(
        name="...",             # replace with the package name
        version="1.0.0",        
        description="...",      # replace with a short description
        author="...",           # replace with your name
        author_email="...",     # replace with your email
        ext_modules=[
            Extension("example", ["example.c"])
        ] # replace with the package name and the source file name
    )

if __name__ == '__main__':
    main()