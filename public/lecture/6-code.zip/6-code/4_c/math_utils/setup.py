from distutils.core import setup, Extension

def main():
    setup(name="math_utils",
          version="1.0.0",
          description="C interface for some math utilities",
          author="Parth Sarin",
          author_email="psarin@stanford.edu",
          ext_modules=[Extension("math_utils", ["math_utils.c"])])

if __name__ == '__main__':
    main()
