#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <math.h>

static PyObject* 
square(PyObject *self, PyObject *args) {
    long int n;
    if (!PyArg_ParseTuple(args, "l", &n)) {
        return NULL;
    }

    return PyLong_FromLong(n * n);
}

static PyObject*
py_sqrt(PyObject *self, PyObject *args) {
    long int n;
    if (!PyArg_ParseTuple(args, "l", &n)) {
        return NULL;
    }

    // If n is negative, raise a ValueError
    if (n < 0) {
        return PyErr_Format(
            PyExc_ValueError, 
            "Cannot take the square root of a negative number"
        );
    }

    // Otherwise, return the square root of n
    return PyFloat_FromDouble(sqrt(n));
}

static PyObject* 
is_prime(PyObject *self, PyObject *args) {
    long int n;
    if (!PyArg_ParseTuple(args, "l", &n)) {
        return NULL;
    }

    // 0 and 1 are not prime numbers
    if (n <= 1) {
        return Py_False;
    }

    // Otherwise, loop up to the square root of n
    for (long int i = 2; i <= sqrt(n); i++) {
        // If n is divisible by i, return False
        if (n % i == 0) {
            return Py_False;
        }
    }

    // If we get here, n is prime
    return Py_True;
}

long long m_factorial(long int n) {
    long long output = 1LL;
    for (int i = 1; i <= n; i++)
        output *= i;
    return output;
}

static PyObject*
factorial(PyObject *self, PyObject *args) {
    long int n;
    if (!PyArg_ParseTuple(args, "l", &n)) {
        return NULL;
    }

    // If n is negative, raise a ValueError
    if (n < 0) {
        return PyErr_Format(
            PyExc_ValueError, 
            "Cannot take the factorial of a negative number"
        );
    }

    // Otherwise, return the factorial of n
    return PyLong_FromLongLong(m_factorial(n));
}

static PyMethodDef MathUtilMethods[] = {
    {"square", square, METH_VARARGS, "Python method for squaring a number"},
    {"sqrt", py_sqrt, METH_VARARGS, "Take the square root of a number"},
    {"is_prime", is_prime, METH_VARARGS, "Check if a number is prime"},
    {"factorial", factorial, METH_VARARGS, "Take the factorial of a number"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef mathutils = {
    PyModuleDef_HEAD_INIT,
    "math_utils",
    "C interface for some math utilities",
    -1,
    MathUtilMethods
};

PyMODINIT_FUNC PyInit_math_utils(void) {
    return PyModule_Create(&mathutils);
}

