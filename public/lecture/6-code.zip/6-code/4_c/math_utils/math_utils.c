#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <math.h>

static PyObject* 
square(PyObject *self, PyObject *args) {
    return PyErr_Format(
        PyExc_NotImplementedError, 
        "The square function hasn't been implemented"
    );
}

static PyObject*
py_sqrt(PyObject *self, PyObject *args) {
    return PyErr_Format(
        PyExc_NotImplementedError, 
        "The sqrt function hasn't been implemented"
    );
}

static PyObject* 
is_prime(PyObject *self, PyObject *args) {
    return PyErr_Format(
        PyExc_NotImplementedError, 
        "The is_prime function hasn't been implemented"
    );
}

static PyObject*
factorial(PyObject *self, PyObject *args) {
    return PyErr_Format(
        PyExc_NotImplementedError, 
        "The factorial function hasn't been implemented"
    );
}

static PyMethodDef MathUtilMethods[] = {
    {"square", square, METH_VARARGS, "Python method for squaring a number"},
    {"sqrt", py_sqrt, METH_VARARGS, "Take the square root of a number"},
    {"is_prime", is_prime, METH_VARARGS, "Check if a number is prime"},
    {"factorial", factorial, METH_VARARGS, "Take the factorial of a number"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef mathutils = {
    PyModuleDef_HEAD_INIT,
    "math_utils",
    "C interface for some math utilities",
    -1,
    MathUtilMethods
};

PyMODINIT_FUNC PyInit_math_utils(void) {
    return PyModule_Create(&mathutils);
}

