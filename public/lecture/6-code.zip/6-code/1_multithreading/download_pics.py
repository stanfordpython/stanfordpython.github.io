import requests
from threading import Thread
from timeit import timeit
from os import system

FILES = [
    ('https://cataas.com/cat/says/hello%20world!', 'downloads/hello-world.jpg'),
    ('https://cataas.com/cat/says/i%20love%20python!', 'downloads/love-python.jpg'),
    ('https://cataas.com/cat/says/tara%20is%20the%20best%20%3C3', 'downloads/tara.jpg'),
    ('https://cataas.com/cat/says/will%20is%20so%20cool%20B)', 'downloads/will.jpg')
]

def download_picture(url, filename):
    r = requests.get(url)
    open(filename, 'wb').write(r.content)

def download_loop():
    for url, filename in FILES:
        download_picture(url, filename)

def download_threads():
    ...

def main():
    # Download the pictures using a loop
    print('Downloading the pictures using a loop...')
    t = timeit(
        f'download_loop()',
        number=1,
        setup='from __main__ import download_loop'
    )
    print(f'Took {t} seconds')

    # Pause the program so we can see the results
    input('Press enter to continue...')
    system('rm -rf downloads/*')

    # Download the pictures using threads
    print('Downloading the pictures using threads...')
    t = timeit(
        f'download_threads()',
        number=1,
        setup='from __main__ import download_threads'
    )
    print(f'Took {t} seconds')

if __name__ == '__main__':
    main()
