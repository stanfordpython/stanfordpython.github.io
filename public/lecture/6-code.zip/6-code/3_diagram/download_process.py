from threading import Thread
from PIL import Image, ImageFilter
import requests
from io import BytesIO

FILES = [
    ('https://cataas.com/cat/says/hello%20world!', 'downloads/hello-world.jpg'),
    ('https://cataas.com/cat/says/i%20love%20python!', 'downloads/love-python.jpg'),
    ('https://cataas.com/cat/says/tara%20is%20the%20best%20%3C3', 'downloads/tara.jpg'),
    ('https://cataas.com/cat/says/will%20is%20so%20cool%20B)', 'downloads/will.jpg')
]

def download_picture(url, filename):
    # Download the image
    r = requests.get(url)

    # Convert the image to PIL format
    img = Image.open(BytesIO(r.content))

    # Apply a filter to the image and save
    img = img.filter(ImageFilter.FIND_EDGES)
    img.save(filename)


def download_threads():
    threads = [
        Thread(
            target=download_picture,
            args=(url, filename)
        )
        for url, filename in FILES
    ]

    for thread in threads:
        thread.start()

    for thread in threads:
        thread.join()


if __name__ == '__main__':
    download_threads()