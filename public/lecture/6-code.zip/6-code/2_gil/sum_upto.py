"""
File: sum_upto.py
-------------------------

This program compares the performance of calling sum in a loop versus calling 
sum using threads. The goal is to demonstrate that threads are not useful for 
CPU-bound tasks.

Note: On my computer `$ python sum_upto.py 100 2000000` is a good test
"""
from threading import Thread
from timeit import timeit
from sys import argv


def sum_upto(n):
    """
    Returns the sum of numbers one up to n.
    """
    output = 0
    for i in range(1, n+1):
        output += i
    return output


def sum_upto_loop(k, n):
    """
    Calls sum_upto(n) k times in a loop.
    """
    for _ in range(k):
        sum_upto(n)


def sum_upto_thread(k, n):
    """
    Calls sum_upto(n) k times using threads.
    """
    pool = [Thread(target=sum_upto, args=(n, )) for _ in range(k)]
    for thread in pool:
        thread.start()
    for thread in pool:
        thread.join()


def main():
    # Parse the arguments from the command line
    assert len(argv) == 3, 'Invalid number of arguments.'
    _, k, n = argv
    k, n = int(k), int(n)

    # Call sum_upto(n) k times in a loop
    print(f'Calling sum_upto({n}) in a loop, {k} times')
    t = timeit(
        f"sum_upto_loop({k}, {n})",
        number=1,
        setup='from __main__ import sum_upto, sum_upto_loop'
    )
    print(f'Took {t} seconds')

    # Call sum_upto(n) k times using threads
    print(f'Calling sum_upto({n}) using threads, {k} times')
    t = timeit(
        f"sum_upto_thread({k}, {n})",
        number=1,
        setup='from __main__ import sum_upto, sum_upto_thread'
    )
    print(f'Took {t} seconds')


if __name__ == '__main__':
    main()
