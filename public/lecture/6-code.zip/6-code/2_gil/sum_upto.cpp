/* File: sum_upto.cpp
 *
 * Usage: ./sum_upto [k] [n]
 *
 *  k -- the number of times to call the factorial function
 *  n -- the value to compute the factorial of
 *
 * Notes: 
 *  - On my computer, `$ ./sum_upto 100 50000000` is a good test
 *  - It's challenging to time multithreaded programs because most timers rely on
 *  the system clock. Instead, we use the MacOS clock library, so this program
 *  will only work on MacOS.
 * 
 * Compile with:
 *  $ g++ -std=c++11 sum_upto.cpp -o sum_upto
 */

#include <iostream>
#include <thread>
#include <string>
#include <vector>
#include <time.h>

using namespace std;
typedef struct timespec t_time;

/**
 * Computes the sum up to a number
 * @param n the number to compute the sum up to
 * @return the sum up to
*/
long long sum_upto(int n) {
    long long output = 0LL;
    for (long long i = 1LL; i <= n; i++) {
        output += i;
    }
    return output;
}

/**
 * Calls the sum_upto function k times using threads
*/
void sum_upto_thread(int k, int n) {
    vector<thread> pool(k);

    // start the threads
    for (int i = 0; i < k; i++) {
        pool[i] = thread(sum_upto, n);
    }

    // join the threads
    for (int i = 0; i < k; i++) {
        pool[i].join();
    }
}

/**
 * Calls the sum_upto function k times in a loop
*/
void sum_upto_loop(int k, int n) {
    for (int i = 0; i < k; i++)
        sum_upto(n);
}

/**
 * Compute the difference between two times
*/
double get_elapsed(t_time start, t_time end) {
    double elapsed = (end.tv_sec - start.tv_sec);
    elapsed += (end.tv_nsec - start.tv_nsec) / 1000000000.0;
    return elapsed;
}

int main(int argc, char *argv[]) {
    // error checking
    if (argc != 3) {
        cout << "Invalid call" << endl;
        cout << "Usage: ./sum_upto [k] [n]" << endl;
        return 1;
    }

    // get the arguments
    int k = stoi(argv[1]);
    int n = stoi(argv[2]);
    t_time start, end;

    // call sum_upto(n) k times in a loop
    cout << "Calling sum_upto(" << n << ") in a loop, " << k << " times" << endl;
    clock_gettime(CLOCK_MONOTONIC, &start);
    sum_upto_loop(k, n);
    clock_gettime(CLOCK_MONOTONIC, &end);
    cout << "Took " << get_elapsed(start, end) << " seconds" << endl;

    // call sum_upto(n) k times using threads
    cout << "Calling sum_upto(" << n << ") using threads, " << k << " times" << endl;
    clock_gettime(CLOCK_MONOTONIC, &start);
    sum_upto_thread(k, n);
    clock_gettime(CLOCK_MONOTONIC, &end);
    cout << "Took " << get_elapsed(start, end) << " seconds" << endl;
}
