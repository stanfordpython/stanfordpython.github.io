from flask import Flask

app = Flask(__name__)
SECRET_NUMBER = int(open('SECRET_NUMBER').read())

@app.route('/<guess>', methods=['GET'])
def check(guess):
    # 1. convert the guess into an integer
    guess = guess.strip()
    if not guess.isnumeric():
        return {'error': "That's not an integer!"}
    guess = int(guess)

    # 2. compare it to the secret number
    output = {'correct': guess == SECRET_NUMBER}
    if guess < SECRET_NUMBER:
        output['error'] = 'too low'
    elif guess > SECRET_NUMBER:
        output['error'] = 'too high'
    else:
        output['message'] = 'congrats! you got it :)'

    return output

@app.route('/', methods=['GET'])
def index():
    return 'Hello world!'