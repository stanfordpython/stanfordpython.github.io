PHRASES = [
    "COLD WINDOWSILL",
    "COOL MILLION",
    "VIVID DISILLUSIONS",
    "SUSPICIOUS CONCLUSION",
    "CHILLY WINDOW LEDGE",
    "GOOD THOUSAND THOUSAND",
    "GRAPHIC DISAPPOINTMENTS",
    "MISTRUSTFUL ENDING",
]


def is_efficient(phrase):
    raise NotImplementedError("is_efficient hasn't been implemented")

def categorize(phrase):
    if is_efficient(phrase):
        print(f'✔ {phrase} is efficient')
    else:
        print(f'✘ {phrase} is not efficient')

if __name__ == '__main__':
    for phrase in PHRASES:
        categorize(phrase)
