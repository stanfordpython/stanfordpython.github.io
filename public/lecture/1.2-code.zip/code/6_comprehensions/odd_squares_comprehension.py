def odd_squares_below(num):
    return [
        i ** 2
        for i in range(int(num ** (1/2)))
        if (i ** 2) % 2 != 0
    ]

if __name__ == '__main__':
    print(odd_squares_below(100))
