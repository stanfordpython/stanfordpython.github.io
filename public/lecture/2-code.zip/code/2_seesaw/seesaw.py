"""
File: seesaw.py
---------------
Write a function called seesaw_words, which takes in two strings and
prints out a pattern where the first word "turns into" the second word.
"""


def seesaw_words(s1, s2):
    ... # replace this with your implementation!


if __name__ == '__main__':
    seesaw_words('telephone', 'television')
    seesaw_words('parth', 'tara')
    seesaw_words('telephone', 'megaphone')
