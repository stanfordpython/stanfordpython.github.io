def is_bright(tup):
    avg_val = sum(tup) / 3
    return avg_val >= 128

def filter_pixels(pixels):
    # apply is_bright to filter the list
    ...

if __name__ == '__main__':
    filter_pixels([
        (11, 231, 128), (224, 178, 46), (226, 226, 133), (225, 83, 205),
        (37, 89, 102), (119, 67, 141), (170, 239, 125), (135, 22, 2),
        (83, 105, 96), (16, 19, 96)
    ])
