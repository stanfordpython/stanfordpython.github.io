def odd_squares_below(num):
    output = []
    loop_max = int(num ** (1/2))
    for i in range(loop_max):
        if (i ** 2) % 2 != 0:
            output.append(i ** 2)
    return output

if __name__ == '__main__':
    print(odd_squares_below(100))
