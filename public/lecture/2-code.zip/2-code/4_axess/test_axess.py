from axess import *

F22 = {
    'Magic 101': Course(1, 'SPELLS', 101, 'Fall 2022', {}),
    'Potions 231': Course(10, 'POTIONS', 231, 'Fall 2022', {1}),
    'Creatures 140': Course(7, 'CREATURES', 140, 'Fall 2022', {})
}

W23 = {
    'Levitation 10': Course(2, 'LEVITATION', 10, 'Winter 2023', {}),
    'Magic 199': Course(4, 'MAGIC', 199, 'Winter 2023', {1}),
    'History 381': Course(6, 'HISTORY', 381, 'Winter 2023', {1, 7}),
}

S23 = {
    'CS 41': Course(3, 'COMPUTER SCIENCE', 41, 'Spring 2023', {1}),
    'Potions 120': Course(5, 'POTIONS', 120, 'Spring 2023', {1}),
    'Starstuff 35': Course(8, 'STARSTUFF', 35, 'Spring 2023', {6})
}

# Parth's enrollment should work
parth = Student('parth sarin', '8139418')
parth.course_history = [
    F22['Magic 101'],
    F22['Creatures 140'],
    W23['Magic 199']
]
S23['CS 41'].enroll(parth)
S23['Potions 120'].enroll(parth)

print(S23['CS 41'])
print(S23['CS 41'].enrolled)
print(parth.current_courses)

# Tara's enrollment should raise an error
tara = Student('tara jones', '4892384')
tara.course_history = [
    F22['Magic 101'],
    F22['Creatures 140'],
    W23['Magic 199']
]
S23['CS 41'].enroll(tara)
S23['Starstuff 35'].enroll(tara) # shouldn't work

print(S23['CS 41'].enrolled)
print(parth.current_courses)
