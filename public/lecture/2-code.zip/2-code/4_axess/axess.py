class Student:
    def __init__(self, name, sunet):
        self.name = name
        self.sunet = sunet
        self.course_history = []
        self.current_courses = []

class Course:
    def __init__(self, course_id, dept, course_num, qtr, prereqs):
        self.course_id = course_id
        self.dept = dept
        self.course_num = course_num
        self.qtr = qtr
        self.prereqs = prereqs
        self.enrolled = []

    def enroll(self, student):
        ...
