def odd_squares_below(num):
    ...

if __name__ == '__main__':
    print(odd_squares_below(100))
