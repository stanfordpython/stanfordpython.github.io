PHRASES = [
    "COLD WINDOWSILL",
    "COOL MILLION",
    "VIVID DISILLUSIONS",
    "SUSPICIOUS CONCLUSION",
    "CHILLY WINDOW LEDGE",
    "GOOD THOUSAND THOUSAND",
    "GRAPHIC DISAPPOINTMENTS",
    "MISTRUSTFUL ENDING",
]

EFF_LETTERS = set('BCDGIJLMNOPRSUVWZ ')

def is_efficient(phrase):
    return set(phrase) <= EFF_LETTERS

def categorize(phrase):
    if is_efficient(phrase):
        print(f'✔ {phrase} is efficient')
    else:
        print(f'✘ {phrase} is not efficient')

if __name__ == '__main__':
    for phrase in PHRASES:
        categorize(phrase)
