import time

def timeit(fn):
    def timed(*args, **kwargs):
        start = time.time()
        out = fn(*args, **kwargs)
        end = time.time()

        print(f'Took {end - start:.4f} seconds')
        return out
    return timed

@timeit
def factorial(n):
    output = 1
    for i in range(1, n + 1):
        output *= i
    return output


if __name__ == '__main__':
    print('Calling factorial(100)...')
    factorial(100)

    print('Calling factorial(10_000)...')
    factorial(10000)

    print('Calling factorial(100_000)...')
    factorial(100000)
