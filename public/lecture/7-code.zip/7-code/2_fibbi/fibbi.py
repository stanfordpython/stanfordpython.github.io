def fibbi():
    a = 0
    b = 1

    while True:
        temp = a + b
        a = b
        b = temp

        yield a
