class Student:
    def __init__(self, name, sunet):
        self.name = name.title()

        if not set(sunet) <= set('0123456789'):
            raise ValueError(f'Invalid sunet: {sunet}')
        self.sunet = sunet

        self.course_history = []
        self.current_courses = []

    def __repr__(self):
        return f'<Student: {self.name}>'

class Course:
    def __init__(self, course_id, dept, course_num, qtr, prereqs):
        self.course_id = course_id
        self.dept = dept
        self.course_num = course_num
        self.qtr = qtr
        self.prereqs = prereqs
        self.enrolled = []

    def enroll(self, student):
        student_history = {c.course_id for c in student.course_history}
        if not self.prereqs <= student_history:
            raise ValueError(f"{student.name} doesn't have the prerequisites for this class")

        self.enrolled.append(student)
        student.current_courses.append(self)

    def __repr__(self):
        return f'<Course: {self.dept} {self.course_num} (id: {self.course_id})>'
