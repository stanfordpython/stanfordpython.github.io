import functools
import time

# Example 1: cache decorator
@functools.cache
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

@functools.cache
def fibonacci_non_cache(n):
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

start_time = time.time()
print(fibonacci(35))
end_time = time.time()
execution_time = end_time - start_time
print(f'Execution time (cached): {execution_time} seconds.')

start_time = time.time()
print(fibonacci(50))
end_time = time.time()
execution_time = end_time - start_time
print(f"Execution time (cached): {execution_time} seconds")

start_time = time.time()
print(fibonacci_non_cache(50))
end_time = time.time()
execution_time = end_time - start_time
print(f"Execution time FOR NON cached: {execution_time} seconds")

# Example 2: wraps decorator
def debug_decorator(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        print(f"Calling function: {func.__name__}")
        return func(*args, **kwargs)
    return wrapper

@debug_decorator
def add(a, b):
    """Adds two numbers"""
    return a + b

print(add(2, 3))  # Output: Calling function: add
                  #         5
print(add.__name__)  # Output: add
print(add.__doc__)  # Output: Adds two numbers


# Example 3: partial function
def multiply(a, b, c):
    return a * b * c

double = functools.partial(multiply, b=2)
triple = functools.partial(multiply, b=3)

print(double(4, c=5))  # Output: 40 (2 * 4 * 5)
print(triple(4, c=5))  # Output: 60 (3 * 4 * 5)
