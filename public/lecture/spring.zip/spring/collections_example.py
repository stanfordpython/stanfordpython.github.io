from collections import Counter, defaultdict, namedtuple, deque

# Counter - Counting elements in a sequence
numbers = [1, 2, 3, 4, 1, 2, 3, 1, 2, 1]
count = Counter(numbers)
print("Counter:", count)
print("Most common elements:", count.most_common(2))
print("Total occurrences of 1:", count[1])

#defaultdict - Default values for missing keys

s = [('yellow', 1), ('blue', 2), ('yellow', 3), ('blue', 4), ('red', 1)]
d = defaultdict(list)
# d = {}
for k, v in s:
    d[k].append(v)
print(d)


fruits = defaultdict(lambda: "Unknown")
fruits["apple"] = "Red"
fruits["banana"] = "Yellow"
print("Fruits:", fruits)
print("Color of mango:", fruits["mango"])

# namedtuple - Creating named tuples
Person = namedtuple("Person", ["name", "age", "city"])
person1 = Person("Alice", 25, "New York")
person2 = Person("Bob", 30, "London")
print("Person 1:", person1)
print("Person 2:", person2)
print("Person 1 name:", person1.name)



