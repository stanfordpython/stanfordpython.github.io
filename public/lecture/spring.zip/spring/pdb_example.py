

def divide_numbers(a, b):
    result = a / b
    return result

def main():
    num1 = 10
    num2 = 0
    result = divide_numbers(num1, num2)
    print("Result:", result)

if __name__ == "__main__":
    main()
