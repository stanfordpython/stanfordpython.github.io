import re

# Example 1: findall
text = "John: +1 (123) 456-7890, Jane: +4 (987) 654-3210, Mike: 123456789"
pattern = r'\+\d{1,2}\s?\(\d{3}\)\s?\d{3}-\d{4}'
matches = re.findall(pattern, text)

print("Find all phone numbers in the text:")
print(matches)
print()

# Example 2: match
phone_number1 = "+1 (123) 456-7890"
phone_number2 = "987-654-3210"
phone_number3 = "123456789"

pattern = r'^\+\d{1,2}\s?\(\d{3}\)\s?\d{3}-\d{4}$'
match1 = re.match(pattern, phone_number1)
match2 = re.match(pattern, phone_number2)
match3 = re.match(pattern, phone_number3)

print("Match the pattern for phone numbers:")
print(f"Phone number 1: {match1}")
print("span", match1.span())
print("string", match1.string)
print(f"Phone number 2: {match2}")
print(f"Phone number 3: {match3}")
