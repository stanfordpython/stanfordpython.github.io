from itertools import cycle, count

# Example 1: cycle
fruits = ['apple', 'banana', 'cherry']
fruit_cycle = cycle(fruits)

# Print the first 10 elements of the cycle
for _ in range(10):
    print(next(fruit_cycle))

print()

# Example 2: Normal Iterator
fruits_iter = iter(fruits)

# Print the first 10 elements of the normal iterator
for _ in range(10):
    print(next(fruits_iter))

# Example 2: count
start = 1
step = 2
counter = count(start, step)

# Print the first 5 elements of the count
for _ in range(5):
    print(next(counter))
