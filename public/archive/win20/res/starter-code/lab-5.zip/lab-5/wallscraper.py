#!/usr/bin/env python3
"""
Reddit Wallscraper
Course: CS 41
Name: <YOUR NAME>
SUNet: <SUNet ID>

Replace this with a description of the program.
"""
import utils


class RedditPost:
    def __init__(self, data):
        pass

    def download(self):
        pass

    def __str__(self):
        return ""

    
def query():
    pass
    
    
def main():
    pass

if __name__ == '__main__':
    main()
